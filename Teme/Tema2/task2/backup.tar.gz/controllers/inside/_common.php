<?php

/**
 * Common functions used by all controllers.
 */
class InsideCommon extends Controller
{
	public function __construct($parent = null) {	
		$this->usesDatabase = true;
		$this->templatePath = '/inside';
		$this->controllerPath = '/inside';
		parent::__construct($parent);
	}

	protected function _common()
	{
		if (empty($_SESSION['auth'])) {
			$this->Redirect('/?err=403');
		}
		$userId = $_SESSION['auth']['id'];
		$stmt = $this->db->Query(
			"SELECT a.`username`, a.`fullname`, a.`profile_img`, `f`.valid ".
			"FROM `friends` f INNER JOIN `accounts` a ON f.`friend_id` = a.`id` ".
			"WHERE f.`user_id` = ? ORDER BY a.`id` LIMIT 10", [$userId]);
		$friends = [];
		while ($row = $stmt->fetch()) {
			$friends[] = $row;
		}
		$this->Assign('friends', $friends);

		$userId = $_SESSION['auth']['id'];
		$stmt = $this->db->Query(
			"SELECT a.`username`, a.`fullname`, a.`profile_img` ".
			"FROM `accounts` a ".
			"WHERE a.`id` <> ? AND NOT EXISTS (".
			"  SELECT 1 FROM `friends` `f` WHERE (f.friend_id = a.id AND f.user_id = ?) ".
			"    OR (f.friend_id = a.id AND f.friend_id = ?) ) ".
			"ORDER BY RAND() LIMIT 5", [$userId, $userId, $userId]);
		$youmayknow = [];
		while ($row = $stmt->fetch()) {
			$youmayknow[] = $row;
		}
		$this->Assign('youmayknow', $youmayknow);
	}
	
}

