<?php

require_once(dirname(__FILE__).'/_common.php');

class Friends extends InsideCommon
{
	public function __construct($parent = null) {	
		parent::__construct($parent);
	}

	public function add($param=null, $accept=false)
	{
		if (empty($_GET['id'])) {
			echo '{ "error": "invalid friend ID" }';
			return;
		}
		try {
			$friendId = $_GET['id'];
			$stmt = $this->db->Query("SELECT * FROM `friends` WHERE `user_id` = ? AND friend_id = ?",
				[$_SESSION['auth']['id'], $friendId]);
			$friend = $stmt->fetch();
			if ($friend) {
				$this->db->Query("UPDATE `friends` SET `valid`=1 WHERE ".
					"(`user_id` = ? AND `friend_id` = ?) OR ",
					"(`friend_id` = ? AND `user_id` = ?)",
					[$friendId, $_SESSION['auth']['id'], 
					 $friendId, $_SESSION['auth']['id']]);
			} else {
				$this->db->Query("INSERT INTO `friends` (`friend_id`, `user_id`, `valid`) VALUES ".
					"(?, ?, 0), (?, ?, 0)",
					[$_SESSION['auth']['id'], $friendId,
					 $friendId, $_SESSION['auth']['id']]);
			}
			echo '{ "success": true }';
			return;
		} catch (\Exception $e) {
			echo json_encode(["error" => $e->getMessage()]);
			return;
		}
	}

	public function accept() {
		echo '{ "error": "not implemented (simulated by friends-daemon)!" }';
		return;
		// $this->add(null, true);
	}

}

