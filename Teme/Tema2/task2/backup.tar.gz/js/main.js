// utility site functions

/**
 * Called on a user's profile page to add it as friend.
 */
function addFriendProfile() {
	var userId = $('.profile-view').data('userId');
	// send ajax GET request to the server
	$.get("/inside/friends/add?id=" + userId, function(data) {
		// reload the page to see your new friends
		window.location.reload();
	});
}

/**
 * Function to approve a friendship request.
 *
 * The numeric ID of the user is required as parameter.
 */
function acceptFriend(friendId) {
	// note: call this function by name (do not take its contents)
	$.get("/inside/friends/accept?id=" + friendId, function(data) {
		// reload the page to see your new friends
		window.location.reload();
	});
}

/* On document load callback */
$(function() {
	// add action for the addImage post button
	$('#newPostForm .addImage').click(function(event) {
		event.preventDefault();
		$("#newPostForm .imageUpload").show();
	});

	// add action for the profile add friend button
	$('.profile-view .addFriend').click(function(event) {
		event.preventDefault();
		addFriendProfile();
	});
});

