<?php
/* Web app configuration file */

// the last flag will be inside the real config.php
// you'll have to work pretty hard to get it!
DEFINE("LAST_FLAG", "https://www.youtube.com/watch?v=pOyK9qQpdyQ");

DEFINE("DATABASE_CONFIG", array(
	"host" => "mysql",
	"username" => "test",
	"password" => "test1234",
	"database" => "mysql",
));

