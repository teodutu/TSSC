<?php
/* Load Config */
require_once(dirname(__FILE__) . '/config.php');

/** Load Base MVC Objects */
require_once(dirname(__FILE__) . '/lib/autoload.php');

// parse the 'p' path received from nginx
$url = empty($_GET['p']) ? "/" . DEFAULT_CONTROLLER : $_GET['p'];
// remove leading '/'
$url = ($url[0] == '/')  ? substr($url, 1) : $url;
$url = explode('/', $url);

// try to determine the controller path from the URL segments
$controllerDir = '';
$controller = 'Index';
$params = [];
foreach ($url as $i => $component) {
	$curPath = CONTROLLERS . "$controllerDir";
	$curController = ucfirst(strtolower($component));
	if (is_dir("$curPath/$component")) {
		$controllerDir .= "/$component";
		$controller = 'Index';
	} else if (file_exists("$curPath/$curController.php")) {
		$controller = $curController;
		$params = array_slice($url, $i + 1);
		break;
	} else if (file_exists("$curPath/Index.php")) {
		$controller = 'Index';
		$params = array_slice($url, $i);
		break;
	} else {
		$controller = $curController;
		$params = array_slice($url, $i + 1);
		break;
	}
}

/** 
 * Include the Controller and Instantiate it 
 */
if (file_exists(CONTROLLERS . "$controllerDir/$controller.php"))
{
	require_once(CONTROLLERS . "$controllerDir/$controller.php");
	$object = new $controller();
	$object->Dispatch($params);
}
/** If Controller does not exist */
else
{
	http_response_code(404);
	echo "<h1>Error:</h1> The file: <b>'".CONTROLLERS."$controllerDir/$controller.php'</b> does not exist.";
	exit;
}

